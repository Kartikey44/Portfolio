import React from 'react'
import Hero from './component/Hero'
import Navbar from './component/Navbar'
import CodingProfile from './component/CodingProfile'
import Skills from './component/Skills'
import Education from './component/Education'
import Work from './component/Work'
import Footer from './component/Footer'
import About from './component/About'
import Projects from './component/Projects'
import Contacts from './component/Contacts'
import { Toaster } from 'react-hot-toast'
function App() {
  return (
    <div className='bg-[#1a1a1a] text-[#a0a0a0] min-h-screen md:min-w-7xl p-5 pt-24'>
      <Toaster/>
      <Navbar />
      <Hero />
      <About />
      <Skills />
      <Work />
      <Projects/>
      <CodingProfile />
      <Education />
      <Contacts/>
      <Footer/>
      
    </div>
  )
}

export default App